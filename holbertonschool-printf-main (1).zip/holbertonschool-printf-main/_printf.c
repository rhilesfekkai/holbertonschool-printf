#include "main.h"

/**
 *
 *
 *
 */

int _printf(const char *format, ...);

